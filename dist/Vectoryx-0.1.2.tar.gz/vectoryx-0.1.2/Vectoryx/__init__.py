from .Vectoryx import (
    sum_vectors,
    vector_dif,
    dot_product,
    multiply_vector_to_C,
    vector_length,
    normalize_vector,
    cross_product,
    is_colinear,
    is_ortogonal
)
