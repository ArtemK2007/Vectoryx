from Vectoryx import sum_vectors, vector_dif, dot_product, multiply_vector_to_C, cross_product, normalize_vector, is_colinear, is_ortogonal

print(sum_vectors([1,2,3], [5,6,7]))

print(vector_dif([1,2,3], [5,6,7]))

print(dot_product([1,2,3], [5,6,7]))

print(multiply_vector_to_C([1,2,3], 5))

print(cross_product([1,2,3], [5,6,7]))

print(normalize_vector([1,2,3]))

print(is_colinear([1,2,3], [5,6,7]))

print(is_ortogonal([1,2,3], [5,6,7]))